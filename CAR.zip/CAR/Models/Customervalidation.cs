﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CAR.Models
{
    [MetadataType(typeof(CustMetadata))]
    public partial class customer
    {
        public class CustMetadata
        {
            [DisplayName("CustomerName")]
            public string custname { get; set; }
            [DisplayName("Address")]
            public string address { get; set; }
            [DisplayName("Moblie")]
            public Nullable<int> moblie { get; set; }

        }
    }
}