﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CAR.Models
{
    public class RentalViewmodel
    {
        public int id { get; set; }
        public string carId { get; set; }
        public Nullable<int> custId { get; set; }
        public Nullable<int> fee { get; set; }
        public Nullable<System.DateTime> sdate { get; set; }
        public Nullable<System.DateTime> edate { get; set; }
        public string available { get; set; }
    }
}