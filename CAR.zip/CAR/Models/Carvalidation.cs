﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace CAR.Models
{
    [MetadataType(typeof(carrigmetadata))]
    public partial class  carrig
    {
        public class carrigmetadata
        {
            [DisplayName("CarNo")]
            public string carno { get; set; }

            [DisplayName("Make")]
            public string make { get; set; }

            [DisplayName("Model")]
            public string medel { get; set; }

            [DisplayName("Available")]
            public string available { get; set; }
        }
    }
}