﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data.Entity;
using CAR.Models;
using System.Data.Entity.SqlServer;

namespace CAR.Controllers
{
    public class returncarController : Controller
    {
        SuperCarEntities db = new SuperCarEntities();
        // GET: returncar
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Save(returncar recar)
        {
            if (ModelState.IsValid)
            {
                db.returncars.Add(recar);

                var car = db.carrigs.SingleOrDefault(e => e.carno == recar.carno);
                if (car == null)
                    return HttpNotFound("CarNo not found");
                car.available = "yes";
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(recar);
        }

        [HttpPost]
        public ActionResult Getid(string carno)
        {
            var carn = (from s in db.rentals
                        where s.carId == carno
                        select new
                        {
                            StartDate = s.sdate,
                            EndDate = s.edate,
                            custId = s.custId,
                            Fee = s.fee,
                            ElapsDays = SqlFunctions.DateDiff("day", s.edate, DateTime.Now)
                        }).ToArray();
            return Json(carn,JsonRequestBehavior.AllowGet);
        }
    }
}